from io import BytesIO
from pathlib import Path
from datetime import date
import html
import pandas as pd
import plotly.express as px
import streamlit as st
from utils.database import read_table, add_record, delete_record

STATIONS = {
 "CMN":(33.3675,-7.5898,"Casablanca"), "RAK":(31.6069,-8.0363,"Marrakech"),
 "TNG":(35.7269,-5.9169,"Tanger"), "AGA":(30.3250,-9.4131,"Agadir"),
 "FEZ":(33.9273,-4.9779,"Fès"), "OUD":(34.7872,-1.9239,"Oujda")
}

def _map(df):
    counts=df.groupby("station",as_index=False).agg(orders=("work_order_id","nunique"),
                                                    aircraft=("aircraft_reg","nunique"))
    counts=counts[counts.station.isin(STATIONS)]
    if counts.empty:
        st.info("Aucune escale reconnue dans les filtres.")
        return
    counts["lat"]=counts.station.map(lambda x:STATIONS[x][0])
    counts["lon"]=counts.station.map(lambda x:STATIONS[x][1])
    counts["airport"]=counts.station.map(lambda x:STATIONS[x][2])
    fig=px.scatter_geo(counts,lat="lat",lon="lon",size="orders",color="orders",
        hover_name="airport",hover_data={"station":True,"orders":True,"aircraft":True,"lat":False,"lon":False},
        projection="natural earth",scope="africa",title="Réseau des opérations de maintenance")
    fig.update_geos(lataxis_range=[20,38],lonaxis_range=[-18,4],showland=True,
                    landcolor="#19344f",showocean=True,oceancolor="#071a30",
                    showcountries=True,countrycolor="#54718d")
    fig.update_layout(height=520,margin=dict(l=0,r=0,t=45,b=0),paper_bgcolor="rgba(0,0,0,0)",
                      font_color="#dcecff")
    st.plotly_chart(fig,use_container_width=True)
    st.caption("Positions fixes des aéroports connues dans le jeu de données. Cette carte ne représente ni GPS avion ni suivi de vol en temps réel.")

def render(page, df, filtered, lang="fr"):
    rtl = lang == "ar"
    if rtl:
        st.markdown("<style>.main .block-container{direction:rtl;text-align:right}.stSelectbox,.stTextInput,.stNumberInput,.stTextArea{direction:rtl}</style>",unsafe_allow_html=True)
    if page == "Carte mondiale":
        st.subheader("Carte du réseau de maintenance" if lang!="en" else "Maintenance network map")
        _map(filtered)
        st.dataframe(filtered.groupby("station",as_index=False).agg(
            Ordres=("work_order_id","nunique"),Avions=("aircraft_reg","nunique"),
            Immobilisation_h=("aircraft_downtime_h","sum")),use_container_width=True,hide_index=True)
        return True

    if page == "Fiches avions interactives":
        st.subheader("Fiches avions")
        regs=sorted(filtered.aircraft_reg.dropna().unique().tolist())
        if not regs: st.info("Aucune immatriculation dans les filtres."); return True
        reg=st.selectbox("Immatriculation",regs,key="premium_aircraft_reg")
        d=filtered[filtered.aircraft_reg.eq(reg)].sort_values("open_datetime",ascending=False)
        first=d.iloc[0]
        c1,c2,c3,c4=st.columns(4)
        c1.metric("Type",first.aircraft_type); c2.metric("Âge",f"{first.aircraft_age_years:.0f} ans")
        c3.metric("Heures de vol",f"{first.flight_hours_total:,.0f}"); c4.metric("Cycles",f"{first.flight_cycles_total:,.0f}")
        st.markdown("<div class=\"aircraft-silhouette-panel\"><span>✈</span><small>FICHE TECHNIQUE · DONNÉES DE LA FLOTTE</small></div>", unsafe_allow_html=True)
        st.markdown(f"**{reg}** · {first.aircraft_type} · Historique de {d.work_order_id.nunique()} ordres observés")
        st.dataframe(d[["work_order_id","open_datetime","close_datetime","station","ata_system","finding","priority","status","aircraft_downtime_h"]],use_container_width=True,hide_index=True)
        st.caption("Les heures/cycles et l’âge reprennent les valeurs source les plus récentes du sous-ensemble filtré ; les échéances réglementaires ne sont pas déduites du CSV.")
        return True

    if page == "Planning de maintenance":
        st.subheader("Planning de maintenance — données persistantes")
        with st.form("plan_add",clear_on_submit=True):
            a,b=st.columns(2)
            reg=a.selectbox("Avion",sorted(df.aircraft_reg.unique()))
            task=b.text_input("Intervention / inspection",placeholder="Ex. Inspection visuelle")
            c,d=st.columns(2)
            due=c.date_input("Échéance",value=date.today())
            priority=d.selectbox("Priorité",["Low","Medium","High","AOG"])
            assigned=st.text_input("Responsable")
            notes=st.text_area("Notes")
            submit=st.form_submit_button("Ajouter au planning",use_container_width=True)
        if submit:
            if not task.strip(): st.error("Décris l’intervention avant l’enregistrement.")
            else:
                add_record("maintenance_plan",{"aircraft_reg":reg,"task":task.strip(),"due_date":due.isoformat(),"priority":priority,"status":"Planned","assigned_to":assigned,"notes":notes})
                st.success("Intervention enregistrée dans la base locale."); st.rerun()
        plan=read_table("maintenance_plan")
        if not plan.empty:
            plan["due_date"]=pd.to_datetime(plan.due_date)
            st.dataframe(plan,use_container_width=True,hide_index=True)
            st.markdown("#### Calendrier")
            cal=plan.copy(); cal["Jour"]=cal.due_date.dt.strftime("%d/%m/%Y")
            st.dataframe(cal[["Jour","aircraft_reg","task","priority","status","assigned_to"]].sort_values("Jour"),use_container_width=True,hide_index=True)
            ids=plan.id.tolist()
            chosen=st.selectbox("Supprimer une entrée",ids,format_func=lambda x:f"#{x} · {plan.loc[plan.id.eq(x),'task'].iloc[0]}")
            if st.button("Supprimer l’entrée sélectionnée"): delete_record("maintenance_plan",chosen); st.rerun()
        else: st.info("Le planning est vide. Ajoute une intervention pour commencer.")
        return True

    if page == "Stocks de pièces":
        st.subheader("Gestion des stocks — SQLite persistant")
        with st.form("part_add",clear_on_submit=True):
            c=st.columns(3)
            pn=c[0].text_input("Référence pièce"); desc=c[1].text_input("Description"); loc=c[2].text_input("Magasin / escale")
            c=st.columns(3)
            qty=c[0].number_input("Quantité",min_value=0,step=1); minimum=c[1].number_input("Seuil minimum",min_value=0,step=1); cost=c[2].number_input("Coût unitaire USD",min_value=0.0,step=10.0)
            submit=st.form_submit_button("Ajouter la pièce")
        if submit:
            try:
                if not pn.strip() or not desc.strip(): st.error("Référence et description obligatoires.")
                else: add_record("parts_inventory",{"part_number":pn.strip(),"description":desc.strip(),"quantity":int(qty),"min_quantity":int(minimum),"location":loc,"unit_cost":float(cost)}); st.success("Pièce enregistrée."); st.rerun()
            except Exception as e: st.error(f"Enregistrement impossible : {e}")
        parts=read_table("parts_inventory")
        if not parts.empty:
            parts["Alerte"]=parts.quantity<=parts.min_quantity
            a,b=st.columns(2); a.metric("Références suivies",len(parts)); b.metric("Sous le seuil",int(parts.Alerte.sum()))
            st.dataframe(parts,use_container_width=True,hide_index=True)
            low=parts[parts.Alerte]
            if not low.empty: st.warning("Réapprovisionnement à étudier : "+", ".join(low.part_number.astype(str).tolist()))
            chosen=st.selectbox("Référence à supprimer",parts.id.tolist(),format_func=lambda x:parts.loc[parts.id.eq(x),"part_number"].iloc[0])
            if st.button("Supprimer cette référence"): delete_record("parts_inventory",chosen); st.rerun()
        else: st.info("Aucune pièce enregistrée. Le stock n’est pas inventé à partir des coûts historiques.")
        return True

    if page == "Gestion des techniciens":
        st.subheader("Répertoire des techniciens")
        with st.form("tech_add",clear_on_submit=True):
            a,b=st.columns(2); name=a.text_input("Nom complet"); specialty=b.text_input("Spécialité / habilitation")
            c,d=st.columns(2); station=c.selectbox("Base",sorted(df.station.unique())); email=d.text_input("E-mail")
            availability=st.selectbox("Disponibilité déclarée",["Disponible","Affecté","Absent"])
            submit=st.form_submit_button("Ajouter le technicien")
        if submit:
            if not name.strip(): st.error("Le nom est obligatoire.")
            else: add_record("technicians",{"full_name":name.strip(),"specialty":specialty,"station":station,"email":email,"availability":availability}); st.success("Technicien ajouté."); st.rerun()
        tech=read_table("technicians")
        st.metric("Techniciens répertoriés",len(tech))
        if not tech.empty:
            st.dataframe(tech,use_container_width=True,hide_index=True)
            chosen=st.selectbox("Technicien à supprimer",tech.id.tolist(),format_func=lambda x:tech.loc[tech.id.eq(x),"full_name"].iloc[0])
            if st.button("Supprimer ce technicien"): delete_record("technicians",chosen); st.rerun()
        st.caption("Les compétences et disponibilités sont des données saisies par l’administrateur, pas des habilitations vérifiées.")
        return True

    if page == "AERONEX AI":
        st.subheader("AERONEX AI · Assistant analytique explicable")
        st.warning("Aide à la décision uniquement. Aucun diagnostic, aucune décision de navigabilité et aucune consigne de remise en service.")
        top=filtered.ata_system.value_counts()
        rep=filtered[filtered.repeat_defect.astype(str).str.lower().eq("yes")]
        aog=filtered[(filtered.maintenance_type.eq("AOG"))|(filtered.priority.eq("AOG"))]
        costs=filtered.groupby("aircraft_type").total_cost_usd.sum().sort_values(ascending=False)
        st.markdown("#### Signaux calculés depuis le filtre actif")
        if len(top): st.info(f"Système ATA le plus fréquent : **{top.index[0]}** ({int(top.iloc[0])} ordres).")
        if len(rep): st.warning(f"{len(rep)} ligne(s) portent le marqueur repeat_defect = Yes. Examiner les findings et la chronologie avec l’ingénierie.")
        if len(aog): st.error(f"{aog.work_order_id.nunique()} ordre(s) associés à AOG dans le jeu filtré.")
        if len(costs): st.info(f"Type présentant le coût cumulé observé le plus élevé : **{costs.index[0]}** ({costs.iloc[0]:,.0f} USD).")
        st.markdown("#### Explorer les défauts répétitifs")
        if not rep.empty:
            st.dataframe(rep[["aircraft_reg","aircraft_type","ata_system","finding","open_datetime","work_order_id"]].head(100),use_container_width=True,hide_index=True)
        st.caption("Ce module est une analyse descriptive déterministe ; il n’entraîne pas de modèle prédictif faute de labels, capteurs et validation suffisants.")
        return True

    if page == "Notifications intelligentes":
        st.subheader("Centre de notifications")
        alerts=[]
        for _,r in filtered.iterrows():
            if r.maintenance_type=="AOG" or r.priority=="AOG": alerts.append(("Critique","AOG",r))
            elif str(r.status).lower()=="open" and str(r.priority).lower()=="high": alerts.append(("Élevée","Ordre High ouvert",r))
            elif str(r.repeat_defect).lower()=="yes": alerts.append(("À surveiller","Défaut répétitif",r))
            elif str(r.mel_deferred).lower()=="yes": alerts.append(("À surveiller","MEL différé",r))
        st.metric("Signaux détectés",len(alerts))
        if alerts:
            for severity,label,r in alerts[:100]:
                st.markdown(f"**{severity} · {label}** — {r.aircraft_reg} / {r.work_order_id} · {r.station} · {r.ata_system} · {r.finding}")
        else: st.success("Aucun signal de cette catégorie dans le filtre actif.")
        st.caption("Alertes recalculées à partir du CSV à chaque chargement ; elles ne sont pas des notifications push et ne remplacent pas la surveillance opérationnelle.")
        return True

    if page == "Rapports PDF professionnels":
        st.subheader("Rapport PDF professionnel")
        st.caption("Synthèse descriptive des données filtrées, avec date de génération.")
        if st.button("Générer le rapport PDF"):
            try:
                from reportlab.lib import colors
                from reportlab.lib.pagesizes import A4
                from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
                from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
                buf=BytesIO(); doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=38,leftMargin=38,topMargin=38,bottomMargin=38)
                styles=getSampleStyleSheet(); story=[Paragraph("AERONEX — Rapport de maintenance",styles["Title"]),Spacer(1,10)]
                story.append(Paragraph(f"Généré le {date.today().isoformat()} · {len(filtered)} lignes filtrées",styles["Normal"]))
                story.append(Spacer(1,14))
                summary=[["Indicateur","Valeur"],["Ordres distincts",str(filtered.work_order_id.nunique())],["Avions",str(filtered.aircraft_reg.nunique())],["Coût total USD",f"{filtered.total_cost_usd.sum():,.2f}"],["Immobilisation (h)",f"{filtered.aircraft_downtime_h.sum():,.1f}"],["AOG",str(((filtered.maintenance_type=="AOG")|(filtered.priority=="AOG")).sum())]]
                t=Table(summary,colWidths=[250,220]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#12314d")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.lightgrey),("PADDING",(0,0),(-1,-1),7)])); story.append(t)
                story += [Spacer(1,18),Paragraph("Systèmes ATA les plus représentés",styles["Heading2"])]
                ata=filtered.ata_system.value_counts().head(10)
                rows=[["Système","Ordres"]]+[[str(k),str(v)] for k,v in ata.items()]
                t=Table(rows,colWidths=[350,120]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#d9eaf5")),("GRID",(0,0),(-1,-1),.4,colors.lightgrey),("PADDING",(0,0),(-1,-1),6)])); story.append(t)
                story.append(Spacer(1,14)); story.append(Paragraph("Document analytique. Ne constitue pas un dossier de navigabilité ni une approbation technique.",styles["Italic"]))
                doc.build(story); st.download_button("Télécharger AERONEX_Report.pdf",buf.getvalue(),"AERONEX_Report.pdf","application/pdf")
            except ImportError: st.error("Installe reportlab avec pip install -r requirements.txt.")
        return True
    return False
